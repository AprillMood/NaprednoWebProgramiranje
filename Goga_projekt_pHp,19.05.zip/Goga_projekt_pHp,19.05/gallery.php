<?php 

	print '
	<h1>Gallery</h1>
	<table class="table">
		<tr>
			<td class="td"></td>
			<td class="td">
				<div class="w3-content">
				  <img class="mySlides" src="images/gallery/Big_Waves.jpg" >
				  <img class="mySlides" src="images/gallery/orangeduck.jpg" >
				  <img class="mySlides" src="images/gallery/tunneling.jpg" >
				  <img class="mySlides" src="images/gallery/slider.jpg" >
				  <img class="mySlides" src="images/gallery/riding.jpg" >
				  <img class="mySlides" src="images/gallery/awesome-surfer-girl.jpg" >
				  <img class="mySlides" src="images/gallery/fromabove.jpg" >
				  <img class="mySlides" src="images/gallery/leisure.jpg" >
				  <img class="mySlides" src="images/gallery/breakingthewave.jpg" >
				  <img class="mySlides" src="images/gallery/dancing.jpg" >

				  <button class="w3-button-left" onclick="plusDivs(-1)">&#10094;</button>
				  <button class="w3-button-right" onclick="plusDivs(1)">&#10095;</button>
				</div>
			</td>
			<td class="td"></td>
		</tr>
	</table>
	
	<hr class="hr1">

	<script>
	var slideIndex = 1;
	showDivs(slideIndex);

	function plusDivs(n) {
	  showDivs(slideIndex += n);
	}

	function showDivs(n) {
	  var i;
	  var x = document.getElementsByClassName("mySlides");
	  if (n > x.length) {slideIndex = 1}
	  if (n < 1) {slideIndex = x.length}
	  for (i = 0; i < x.length; i++) {
		x[i].style.display = "none";  
	  }
	  x[slideIndex-1].style.display = "block";  
	}
	</script>
	';


?>