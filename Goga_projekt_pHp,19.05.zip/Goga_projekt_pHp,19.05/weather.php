<?php 

print '
	<h1>Weather forecast</h1>
	<div class="news">';
	
	$arrayCountries = array(2441472, 2442047, 2488853, 2423945, 2348327);
	$arrayCountriesName = array("Long Beach", "California", "Los Angeles", "California", "Santa Cruz", "California", " Honolulu", "Hawaii", "Christchurch", "New Zealand");
	
	print'<table width=100%>
				<thead>
					<tr>
						<td width=10%></td>
						<td width=30%><b>Country</b></td>
						<td width=30%><b>Today</b></td>
						<td width=30%><b>Tomorrow</b></td>
					</tr>
				</thead>';
	
	for($i = 0; $i < count($arrayCountries); $i++){
	
		$url = "https://www.metaweather.com/api/location/".$arrayCountries[$i]."/".date("Y")."/".date("m")."/".date("d");
		$data = json_decode(file_get_contents($url), true);
		$day = date("d") + 1;
		$url1 = "https://www.metaweather.com/api/location/".$arrayCountries[$i]."/".date("Y")."/".date("m")."/".$day;
		$data1 = json_decode(file_get_contents($url1), true);
		
		$pic = $data[0]['weather_state_abbr'];
		$min = $data[0]['min_temp'];
		$max = $data[0]['max_temp'];
		$visi = $data[0]['visibility'];
		$wind = $data[0]['wind_speed'];
		
		$pic1 = $data1[0]['weather_state_abbr'];
		$min1 = $data1[0]['min_temp'];
		$max1 = $data1[0]['max_temp'];
		$visi1 = $data1[0]['visibility'];
		$wind1 = $data1[0]['wind_speed'];

		print'
					<tr style="border-top: thin solid;">
						<td width=10%"></td>
						<td width=30% style="border-top: thin solid;">'.$arrayCountriesName[$i * 2].'<br/>'.$arrayCountriesName[($i * 2) + 1].'</td>
						<td width=30% style="border-top: thin solid;"><img src = "https://www.metaweather.com/static/img/weather/'.$pic.'.svg" ></td>
						<td width=30% style="border-top: thin solid;"><img src = "https://www.metaweather.com/static/img/weather/'.$pic1.'.svg" ></td>
					</tr>
					<tr>
						<td width=10%></td>
						<td width=30%></td>
						<td width=30%>Min: '.number_format($min).'°C<br/>Max: '.number_format($max).'°C<br/>Visibility: '.number_format($visi).'miles<br/>Wind speed: '.number_format($wind).'mph</td>
						<td width=30%>Min: '.number_format($min1).'°C<br/>Max: '.number_format($max1).'°C<br/>Visibility: '.number_format($visi1).'miles<br/>Wind speed: '.number_format($wind1).'mph</td>
					</tr>
			';
	}

print '</table>
	</div>
';
?>